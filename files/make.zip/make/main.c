#include <stdio.h>
#include "funkcje.h"

int main(){
	helloWorld();
	printf("%lu\n", silnia(13));
	return 0;
}
