void helloWorld();
unsigned long int silnia(int n);
