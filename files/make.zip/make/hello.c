#include <stdio.h>

void helloWorld(){
	printf("Hello world!\n");
}
